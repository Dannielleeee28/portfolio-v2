
(function() {
  emailjs.init("PlcxN_UlYvbT9JjWR");
})();

window.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contact-form");
  const message = document.getElementById("form-message");
  const navLinks = document.getElementById("nav-links");
  const menuToggle = document.getElementById("menu-toggle");

  menuToggle.addEventListener("click", () => {
    navLinks.style.display = navLinks.style.display === "flex" ? "none" : "flex";
  });

  form.addEventListener("submit", function(e) {
    e.preventDefault();
    emailjs.sendForm("service_36k4c4r", "template_q24v1mj", this)
      .then(() => {
        message.textContent = "Message sent successfully!";
        message.style.color = "green";
        form.reset();
      }, (err) => {
        message.textContent = "Failed to send message. Please try again.";
        message.style.color = "red";
      });
  });
});
